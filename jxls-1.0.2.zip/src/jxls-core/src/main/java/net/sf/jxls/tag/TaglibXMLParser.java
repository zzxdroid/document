package net.sf.jxls.tag;


/**
 * @author Leonid Vysochyn
 */
public class TaglibXMLParser {
    public static final String TAGLIB_TAG = "taglib";
    public static final String TAG_TAG = "tag";
    public static final String ATTR_TAG = "attribute";
    public static final String ATTR_NAME_TAG = "name";
    public static final String ATTR_REQUIRED_TAG = "required";

    public TaglibXMLParser() {
    }
}
